package com.kaizzinho.cobbletunes.event

import com.cobblemon.mod.common.api.battles.model.PokemonBattle
import com.cobblemon.mod.common.api.battles.model.actor.BattleActor
import com.cobblemon.mod.common.api.battles.model.actor.EntityBackedBattleActor
import com.cobblemon.mod.common.api.events.CobblemonEvents
import com.kaizzinho.cobbletunes.LOGGER
import com.kaizzinho.cobbletunes.MOD_ID
import com.kaizzinho.cobbletunes.config.CobbleTunesServerConfig
import com.kaizzinho.cobbletunes.network.BattleMusicEndPayload
import com.kaizzinho.cobbletunes.network.BattleMusicStartPayload
import com.kaizzinho.cobbletunes.network.PlayerDeathPayload
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking
import net.fabricmc.loader.api.FabricLoader
import java.lang.reflect.Modifier
import java.util.Locale

/**
 * Common/server-side battle classifier.
 *
 * RCT remains a soft dependency. The bridge below has no compile-time references
 * to rctmod/rctapi classes: it identifies RCT's entity-backed Cobblemon actor,
 * reads the TrainerMob ID, and resolves TrainerMobData.getType().id() through
 * reflection only while the rctmod Fabric mod is present.
 *
 * Some Cobbleverse trainers intentionally use an ordinary RCT type even though
 * their progression role is special. For those entries, the stable trainer ID is
 * used as a narrowly-scoped fallback. The wire value remains a String so the
 * existing payload codec does not change:
 *
 *   leader|kanto
 *   e4|hoenn
 *   champ|sinnoh
 *   normal|johto
 *
 * Older/simple values such as "leader" remain valid.
 */
object CobblemonBattleListener {

    fun register() {
        CobblemonEvents.BATTLE_STARTED_POST.subscribe { event ->
            val battle = event.battle

            for (player in battle.players) {
                val playerActor = battle.getActor(player)
                if (playerActor == null) {
                    LOGGER.warn("[$MOD_ID] Could not resolve battle actor for ${player.name.string}, skipping")
                    continue
                }

                // Cobblemon 1.7.3 does not expose BattleActor.side to Kotlin source
                // in this mapped environment. Keep the battle-wide actor path that is
                // already known to compile, excluding the local player's own actor.
                // For the supported 1v1 PvN/PvW/PvP cases, the remaining actor is the
                // opponent (including RCT's TrainerEntityBattleActor).
                val opposingActors: List<BattleActor> = battle.actors
                    .filter { it != playerActor }
                    .toList()

                val opposingSpecies = opposingActors
                    .flatMap { it.pokemonList }
                    .map { it.effectedPokemon.species }

                val legendarySpecies = opposingSpecies.firstOrNull { species ->
                    "legendary" in species.labels || "mythical" in species.labels
                }
                val isLegendary = legendarySpecies != null
                val primarySpecies = legendarySpecies ?: opposingSpecies.firstOrNull()
                val dexNumber = primarySpecies?.nationalPokedexNumber ?: -1
                val opposingDexNumbers = opposingSpecies.map { it.nationalPokedexNumber }

                // RCT creates an EntityBackedBattleActor containing the TrainerMob
                // before Cobblemon emits BATTLE_STARTED_POST. This path therefore does
                // not depend on TrainerManager.addBattle() or TrainerMob.setOpponent().
                val trainerRoute = if (battle.isPvN) {
                    RctBridge.resolveTrainerRoute(battle, opposingActors)
                } else {
                    ""
                }

                if (CobbleTunesServerConfig.current.debugLogging) {
                    LOGGER.info(
                        "[$MOD_ID] [Debug] [Battle payload] player=${player.name.string} " +
                                "battle=${battle.battleId} isWild=${battle.isPvW} " +
                                "isTrainer=${battle.isPvN} route='$trainerRoute' " +
                                "opposingDex=$opposingDexNumbers"
                    )
                }

                ServerPlayNetworking.send(
                    player,
                    BattleMusicStartPayload(
                        isWild = battle.isPvW,
                        isTrainer = battle.isPvN,
                        isLegendary = isLegendary,
                        dexNumber = dexNumber,
                        opposingDexNumbers = opposingDexNumbers,
                        trainerTier = trainerRoute
                    )
                )
            }
        }

        CobblemonEvents.BATTLE_VICTORY.subscribe { event ->
            for (player in event.battle.players) {
                ServerPlayNetworking.send(player, BattleMusicEndPayload)
            }
        }

        CobblemonEvents.BATTLE_FLED.subscribe { event ->
            for (player in event.battle.players) {
                ServerPlayNetworking.send(player, BattleMusicEndPayload)
            }
        }

        // Cobblemon has no BATTLE_DEFEAT event. A real death is distinguished
        // from dimension-change respawns by alive=false.
        ServerPlayerEvents.AFTER_RESPAWN.register { _, newPlayer, alive ->
            if (!alive) {
                ServerPlayNetworking.send(newPlayer, PlayerDeathPayload)
                if (CobbleTunesServerConfig.current.debugLogging) {
                    LOGGER.info("[$MOD_ID] [Debug] Player ${newPlayer.name.string} died — sending PlayerDeathPayload")
                }
            }
        }

        LOGGER.info("[$MOD_ID] CobblemonBattleListener registered (server-side battle classification).")
    }

    /** Reflection-only bridge for Radical Cobblemon Trainers. */
    private object RctBridge {
        private const val RCT_MOD_ID = "rctmod"
        private const val RCT_MOD_CLASS = "com.gitlab.srcmc.rctmod.api.RCTMod"
        private const val ROUTE_SEPARATOR = "|"

        private val supportedTiers = setOf("leader", "e4", "champ", "rival")
        private val supportedRegions = setOf(
            "kanto", "johto", "hoenn", "sinnoh", "unova",
            "kalos", "alola", "galar", "hisui", "paldea"
        )

        /**
         * Cobbleverse's RCT datapack uses IDs such as `kanto_brock`, while the
         * corresponding TrainerMobData currently reports an ordinary/default type.
         * Keep this fallback explicit so unrelated ordinary trainers are never
         * promoted merely because they happen to use a regional prefix.
         */
        private val cobbleverseGymLeaderIds = setOf(
            // Kanto
            "kanto_brock", "kanto_misty", "kanto_ltsurge", "kanto_lt_surge",
            "kanto_erika", "kanto_koga", "kanto_sabrina", "kanto_blaine",
            "kanto_giovanni",
            // Johto
            "johto_valerio", "johto_chiara", "johto_angelo", "johto_alfredo",
            "johto_furio", "johto_jasmine", "johto_raffaello", "johto_sandra",
            // Hoenn
            "hoenn_rudi", "hoenn_adriano", "hoenn_tell_pat", "hoenn_alice",
            "hoenn_norman", "hoenn_fiammetta", "hoenn_walter", "hoenn_petra",
            // Sinnoh
            "sinnoh_gardenia", "sinnoh_ferruccio", "sinnoh_marzia", "sinnoh_fannie",
            "sinnoh_corrado", "sinnoh_bianca", "sinnoh_omar", "sinnoh_pedro"
        )

        private val rctAvailable by lazy {
            FabricLoader.getInstance().isModLoaded(RCT_MOD_ID)
        }

        private var compatibilityFailureLogged = false

        private data class TierProbe(
            val rawTier: String = "",
            val normalizedTier: String = "",
            val trainerDataFound: Boolean = false
        )

        fun resolveTrainerRoute(
            battle: PokemonBattle,
            opposingActors: List<BattleActor>
        ): String {
            if (!rctAvailable) return ""

            return try {
                for (actor in opposingActors) {
                    val entity = (actor as? EntityBackedBattleActor<*>)?.entity ?: continue
                    val trainerId = invokeNoArg(entity, "getTrainerId") as? String ?: continue
                    if (trainerId.isBlank()) continue

                    val normalizedTrainerId = normalizeTrainerId(trainerId)
                    val probe = resolveTierFromEntity(entity, trainerId)
                    val fallbackTier = inferTierFromTrainerId(normalizedTrainerId)
                    val resolvedTier = probe.normalizedTier.ifBlank { fallbackTier }
                    val region = inferRegionFromTrainerId(normalizedTrainerId)
                    val route = encodeRoute(resolvedTier, region)
                    val source = when {
                        probe.normalizedTier.isNotBlank() -> "rct-metadata"
                        fallbackTier.isNotBlank() -> "trainer-id-fallback"
                        else -> "ordinary"
                    }

                    if (CobbleTunesServerConfig.current.debugLogging) {
                        LOGGER.info(
                            "[$MOD_ID] [Debug] [RCT] battle=${battle.battleId} " +
                                    "actor=${actor.javaClass.name} entity=${entity.javaClass.name} " +
                                    "trainerId='$trainerId' dataFound=${probe.trainerDataFound} " +
                                    "rawType='${probe.rawTier.ifEmpty { "missing" }}' " +
                                    "tier='${resolvedTier.ifEmpty { "ordinary" }}' " +
                                    "region='${region.ifEmpty { "unknown" }}' source=$source route='$route'"
                        )
                    }
                    return route
                }

                // This is normal for non-RCT Cobblemon NPCs while rctmod is loaded.
                if (CobbleTunesServerConfig.current.debugLogging) {
                    LOGGER.info(
                        "[$MOD_ID] [Debug] [RCT] No RCT TrainerMob-backed opponent " +
                                "in battle ${battle.battleId}; using ordinary trainer classification"
                    )
                }
                ""
            } catch (e: Exception) {
                logCompatibilityFailure(e)
                ""
            } catch (e: LinkageError) {
                logCompatibilityFailure(e)
                ""
            }
        }

        private fun resolveTierFromEntity(entity: Any, trainerId: String): TierProbe {
            val rctModClass = Class.forName(RCT_MOD_CLASS, false, entity.javaClass.classLoader)
            val getInstance = rctModClass.methods.firstOrNull { method ->
                method.name == "getInstance" &&
                        method.parameterCount == 0 &&
                        Modifier.isStatic(method.modifiers)
            } ?: return TierProbe()

            val rctMod = getInstance.invoke(null) ?: return TierProbe()
            val trainerManager = invokeNoArg(rctMod, "getTrainerManager") ?: return TierProbe()

            // Prefer the stable String overload used by RCT 0.18.1, then fall
            // back to an entity-compatible overload for nearby API versions.
            val trainerData = invokeOneArg(trainerManager, "getData", trainerId)
                ?: invokeOneArg(trainerManager, "getData", entity)
                ?: return TierProbe()

            val type = invokeNoArg(trainerData, "getType")
                ?: return TierProbe(trainerDataFound = true)

            val rawTier = when (type) {
                is String -> type
                else -> (invokeNoArg(type, "id") ?: invokeNoArg(type, "getId"))?.toString()
            }?.trim()?.lowercase(Locale.ROOT).orEmpty()

            return TierProbe(
                rawTier = rawTier,
                normalizedTier = normalizeTier(rawTier),
                trainerDataFound = true
            )
        }

        private fun normalizeTier(rawTier: String): String {
            val normalizedTier = when (rawTier) {
                "leader", "gym_leader", "gymleader" -> "leader"
                "e4", "elite_four", "elitefour", "elite_4" -> "e4"
                "champ", "champion" -> "champ"
                "rival" -> "rival"
                else -> ""
            }
            return normalizedTier.takeIf { it in supportedTiers }.orEmpty()
        }

        private fun inferTierFromTrainerId(trainerId: String): String {
            if (trainerId in cobbleverseGymLeaderIds) return "leader"

            return when {
                trainerId.contains("gym_leader") ||
                        trainerId.startsWith("leader_") ||
                        trainerId.contains("_leader_") -> "leader"

                trainerId.startsWith("e4_") ||
                        trainerId.contains("_e4_") ||
                        trainerId.contains("elite_four") ||
                        trainerId.contains("elite4") -> "e4"

                trainerId.startsWith("champ_") ||
                        trainerId.contains("_champ_") ||
                        trainerId.contains("champion") -> "champ"

                trainerId.startsWith("rival_") ||
                        trainerId.contains("_rival_") -> "rival"

                else -> ""
            }
        }

        private fun inferRegionFromTrainerId(trainerId: String): String =
            supportedRegions.firstOrNull { region ->
                trainerId == region || trainerId.startsWith("${region}_")
            }.orEmpty()

        private fun encodeRoute(tier: String, region: String): String {
            if (tier.isBlank() && region.isBlank()) return ""
            val wireTier = tier.ifBlank { "normal" }
            return if (region.isBlank()) wireTier else "$wireTier$ROUTE_SEPARATOR$region"
        }

        private fun normalizeTrainerId(trainerId: String): String =
            trainerId.trim()
                .lowercase(Locale.ROOT)
                .replace(Regex("[^a-z0-9]+"), "_")
                .trim('_')

        private fun invokeNoArg(target: Any, methodName: String): Any? {
            val method = target.javaClass.methods.firstOrNull {
                it.name == methodName && it.parameterCount == 0
            } ?: return null
            return method.invoke(target)
        }

        private fun invokeOneArg(target: Any, methodName: String, argument: Any): Any? {
            val candidates = target.javaClass.methods.filter {
                it.name == methodName && it.parameterCount == 1
            }

            val method = candidates.firstOrNull {
                it.parameterTypes[0] == argument.javaClass
            } ?: candidates.firstOrNull {
                it.parameterTypes[0].isAssignableFrom(argument.javaClass)
            } ?: return null

            return method.invoke(target, argument)
        }

        private fun logCompatibilityFailure(error: Throwable) {
            if (compatibilityFailureLogged) return
            compatibilityFailureLogged = true
            LOGGER.warn(
                "[$MOD_ID] [RCT] Optional integration is incompatible or unavailable; " +
                        "RCT battles will fall back to ordinary trainer music",
                error
            )
        }
    }
}